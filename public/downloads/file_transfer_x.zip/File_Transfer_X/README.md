File-Transfer
=============

A simple C program to transfer a file (of any size/format) from one machine to another via internet


Running
=============
in a bash/tsch shell, type make run
You will be prompted to select to be either sender or receiver.

Cleaning
=============
in a bash/tsch shell, type make clean
This will clean all non-portable files